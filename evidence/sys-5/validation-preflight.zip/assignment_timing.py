"""Isolated timing of the existing assignment worker's unchanged 20s request."""
import hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'workbench/worker'))
from test_assignment import AssignmentTests,PROFILE
from test_bridge import invoke
case=AssignmentTests('test_fixed_registered_operations_exact_bytes_and_inactive_diagnostics')
record=dict(phase=sys.argv[1],source_sha256=hashlib.sha256((ROOT/'roguelike/generation/authored_rooms.py').read_bytes()).hexdigest(),python=sys.executable,asset=PROFILE,original_timeout_seconds=20,concurrent_verification_workers=0,requests=[])
try:
 case.setUp()
 raw=dict(case.raw,enabled=True,authored_chance=1,candidates=[dict(layout_id='assignment_room',weight=1)])
 for op,kwargs in [('inspect',{}),('preview_draft',dict(source_asset=PROFILE,draft=json.dumps(raw)))]:
  row=dict(operation=op);started=time.perf_counter()
  try:
   result=invoke(op,root=case.root,asset=PROFILE,**kwargs)
   row.update(passed=result['ok'] and result['result']['valid'])
  except Exception as error:row.update(passed=False,error=type(error).__name__+': '+str(error))
  finally:row['request_seconds']=time.perf_counter()-started;record['requests'].append(row)
finally:case.doCleanups()
record['passed']=all(row['passed'] for row in record['requests'])
(ROOT/'.baseline/sys-5'/('assignment-'+sys.argv[1]+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(record));sys.exit(not record['passed'])
