import json,sys,subprocess,pstats,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'workbench/worker'))
from test_assignment import AssignmentTests,PROFILE
from test_bridge import BRIDGE
case=AssignmentTests('test_fixed_registered_operations_exact_bytes_and_inactive_diagnostics')
out=ROOT/'.baseline/sys-5/assignment-profile'
try:
 case.setUp()
 raw=dict(case.raw,enabled=True,authored_chance=1,candidates=[dict(layout_id='assignment_room',weight=1)])
 request=dict(protocol=8,id='timing-diagnostic',op='preview_draft',asset=PROFILE,source_asset=PROFILE,draft=json.dumps(raw))
 start=time.perf_counter()
 r=subprocess.run([sys.executable,'-I','-B','-m','cProfile','-s','cumtime',str(BRIDGE),'--root',str(case.root)],input=json.dumps(request),text=True,capture_output=True,timeout=120,creationflags=0x08000000)
 out.with_suffix('.json').write_text(r.stdout,encoding='utf8')
 print(json.dumps(dict(diagnostic_only=True,seconds=time.perf_counter()-start,returncode=r.returncode,stderr=r.stderr)))
 print(r.stdout[-30000:])
finally:case.doCleanups()
